#ifndef _intvals_h
#define _intvals_h

#define VIDEO_INT    0x10
#define BIOS15_INT   0x15
#define KEYBOARD_INT 0x16
#define DOS_INT      0x21
#define MOUSE_INT    0x33

#endif
