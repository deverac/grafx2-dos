#ifndef _SDL_IMAGE_H
#define _SDL_IMAGE_H

#include "SDL.h"

#endif /* _SDL_IMAGE_H */