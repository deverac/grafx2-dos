#ifdef _SHIM_H
#define _SHIM_H

int snprintf(char* str, size_t size, const char* format, ...);

#endif

